<?php

$installer = $this;
$installer->startSetup();

$installer->run("DROP TABLE IF EXISTS {$this->getTable('webonise_continents_country')}; ");

$table = $installer->getConnection()
    ->newTable($installer->getTable('webonise_continents_country'))
    ->addColumn('id', Varien_Db_Ddl_Table::TYPE_INTEGER, null, array(
        'identity'  => true,
        'unsigned'  => true,
        'nullable'  => false,
        'primary'   => true,
    ), 'ID')
    ->addColumn('code', Varien_Db_Ddl_Table::TYPE_VARCHAR, 100, array(
        'nullable'  => false,
    ), 'Country Code')
    ->addColumn('country', Varien_Db_Ddl_Table::TYPE_VARCHAR, 100, array(
        'nullable'  => false,
    ), 'Country')
    ->addColumn('continent', Varien_Db_Ddl_Table::TYPE_VARCHAR, 100, array(
        'nullable'  => false,
    ), 'Continent');
$installer->getConnection()->createTable($table);

$installer->run(' 
INSERT INTO webonise_continents_country (code, country, continent) values ("AF", "Afghanistan", "Asia"),(
	"AX", "Åland Islands", "Europe"),(
	"AL", "Albania", "Europe"),(
	"DZ", "Algeria", "Africa"),(
	"AS", "American Samoa", "Oceania"),(
	"AD", "Andorra", "Europe"),(
	"AO", "Angola", "Africa"),(
	"AI", "Anguilla", "North America"),(
	"AQ", "Antarctica", "Antarctica"),(
	"AG", "Antigua and Barbuda", "North America"),(
	"AR", "Argentina", "South America"),(
	"AM", "Armenia", "Asia"),(
	"AW", "Aruba", "North America"),(
	"AU", "Australia", "Oceania"),(
	"AT", "Austria", "Europe"),(
	"AZ", "Azerbaijan", "Asia"),(
	"BS", "Bahamas", "North America"),(
	"BH", "Bahrain", "Asia"),(
	"BD", "Bangladesh", "Asia"),(
	"BB", "Barbados", "North America"),(
	"BY", "Belarus", "Europe"),(
	"BE", "Belgium", "Europe"),(
	"BZ", "Belize", "North America"),(
	"BJ", "Benin", "Africa"),(
	"BM", "Bermuda", "North America"),(
	"BT", "Bhutan", "Asia"),(
	"BO", "Bolivia", "South America"),(
	"BA", "Bosnia and Herzegovina", "Europe"),(
	"BW", "Botswana", "Africa"),(
	"BV", "Bouvet Island", "Antarctica"),(
	"BR", "Brazil", "South America"),(
	"IO", "British Indian Ocean Territory", "Asia"),(
	"BN", "Brunei Darussalam", "Asia"),(
	"BG", "Bulgaria", "Europe"),(
	"BF", "Burkina Faso", "Africa"),(
	"BI", "Burundi", "Africa"),(
	"KH", "Cambodia", "Asia"),(
	"CM", "Cameroon", "Africa"),(
	"CA", "Canada", "North America"),(
	"CV", "Cape Verde", "Africa"),(
	"KY", "Cayman Islands", "North America"),(
	"CF", "Central African Republic", "Africa"),(
	"TD", "Chad", "Africa"),(
	"CL", "Chile", "South America"),(
	"CN", "China", "Asia"),(
	"CX", "Christmas Island", "Asia"),(
	"CC", "Cocos (Keeling) Islands", "Asia"),(
	"CO", "Colombia", "South America"),(
	"KM", "Comoros", "Africa"),(
	"CG", "Congo", "Africa"),(
	"CD", "The Democratic Republic of The Congo", "Africa"),(
	"CK", "Cook Islands", "Oceania"),(
	"CR", "Costa Rica", "North America"),(
	"CI", "Cote D\'ivoire", "Africa"),(
	"HR", "Croatia", "Europe"),(
	"CU", "Cuba", "North America"),(
	"CY", "Cyprus", "Asia"),(
	"CZ", "Czech Republic", "Europe"),(
	"DK", "Denmark", "Europe"),(
	"DJ", "Djibouti", "Africa"),(
	"DM", "Dominica", "North America"),(
	"DO", "Dominican Republic", "North America"),(
	"EC", "Ecuador", "South America"),(
	"EG", "Egypt", "Africa"),(
	"SV", "El Salvador", "North America"),(
	"GQ", "Equatorial Guinea", "Africa"),(
	"ER", "Eritrea", "Africa"),(
	"EE", "Estonia", "Europe"),(
	"ET", "Ethiopia", "Africa"),(
	"FK", "Falkland Islands (Malvinas)", "South America"),(
	"FO", "Faroe Islands", "Europe"),(
	"FJ", "Fiji", "Oceania"),(
	"FI", "Finland", "Europe"),(
	"FR", "France", "Europe"),(
	"GF", "French Guiana", "South America"),(
	"PF", "French Polynesia", "Oceania"),(
	"TF", "French Southern Territories", "Antarctica"),(
	"GA", "Gabon", "Africa"),(
	"GM", "Gambia", "Africa"),(
	"GE", "Georgia", "Asia"),(
	"DE", "Germany", "Europe"),(
	"GH", "Ghana", "Africa"),(
	"GI", "Gibraltar", "Europe"),(
	"GR", "Greece", "Europe"),(
	"GL", "Greenland", "North America"),(
	"GD", "Grenada", "North America"),(
	"GP", "Guadeloupe", "North America"),(
	"GU", "Guam", "Oceania"),(
	"GT", "Guatemala", "North America"),(
	"GG", "Guernsey", "Europe"),(
	"GN", "Guinea", "Africa"),(
	"GW", "Guinea-bissau", "Africa"),(
	"GY", "Guyana", "South America"),(
	"HT", "Haiti", "North America"),(
	"HM", "Heard Island and Mcdonald Islands", "Antarctica"),(
	"VA", "Holy See (Vatican City State)", "Europe"),(
	"HN", "Honduras", "North America"),(
	"HK", "Hong Kong", "Asia"),(
	"HU", "Hungary", "Europe"),(
	"IS", "Iceland", "Europe"),(
	"IN", "India", "Asia"),(
	"ID", "Indonesia", "Asia"),(
	"IR", "Iran", "Asia"),(
	"IQ", "Iraq", "Asia"),(
	"IE", "Ireland", "Europe"),(
	"IM", "Isle of Man", "Europe"),(
	"IL", "Israel", "Asia"),(
	"IT", "Italy", "Europe"),(
	"JM", "Jamaica", "North America"),(
	"JP", "Japan", "Asia"),(
	"JE", "Jersey", "Europe"),(
	"JO", "Jordan", "Asia"),(
	"KZ", "Kazakhstan", "Asia"),(
	"KE", "Kenya", "Africa"),(
	"KI", "Kiribati", "Oceania"),(
	"KP", "Democratic People\'s Republic of Korea", "Asia"),(
	"KR", "Republic of Korea", "Asia"),(
	"KW", "Kuwait", "Asia"),(
	"KG", "Kyrgyzstan", "Asia"),(
	"LA", "Lao People\'s Democratic Republic", "Asia"),(
	"LV", "Latvia", "Europe"),(
	"LB", "Lebanon", "Asia"),(
	"LS", "Lesotho", "Africa"),(
	"LR", "Liberia", "Africa"),(
	"LY", "Libya", "Africa"),(
	"LI", "Liechtenstein", "Europe"),(
	"LT", "Lithuania", "Europe"),(
	"LU", "Luxembourg", "Europe"),(
	"MO", "Macao", "Asia"),(
	"MK", "Macedonia", "Europe"),(
	"MG", "Madagascar", "Africa"),(
	"MW", "Malawi", "Africa"),(
	"MY", "Malaysia", "Asia"),(
	"MV", "Maldives", "Asia"),(
	"ML", "Mali", "Africa"),(
	"MT", "Malta", "Europe"),(
	"MH", "Marshall Islands", "Oceania"),(
	"MQ", "Martinique", "North America"),(
	"MR", "Mauritania", "Africa"),(
	"MU", "Mauritius", "Africa"),(
	"YT", "Mayotte", "Africa"),(
	"MX", "Mexico", "North America"),(
	"FM", "Micronesia", "Oceania"),(
	"MD", "Moldova", "Europe"),(
	"MC", "Monaco", "Europe"),(
	"MN", "Mongolia", "Asia"),(
	"ME", "Montenegro", "Europe"),(
	"MS", "Montserrat", "North America"),(
	"MA", "Morocco", "Africa"),(
	"MZ", "Mozambique", "Africa"),(
	"MM", "Myanmar", "Asia"),(
	"NA", "Namibia", "Africa"),(
	"NR", "Nauru", "Oceania"),(
	"NP", "Nepal", "Asia"),(
	"NL", "Netherlands", "Europe"),(
	"AN", "Netherlands Antilles", "North America"),(
	"NC", "New Caledonia", "Oceania"),(
	"NZ", "New Zealand", "Oceania"),(
	"NI", "Nicaragua", "North America"),(
	"NE", "Niger", "Africa"),(
	"NG", "Nigeria", "Africa"),(
	"NU", "Niue", "Oceania"),(
	"NF", "Norfolk Island", "Oceania"),(
	"MP", "Northern Mariana Islands", "Oceania"),(
	"NO", "Norway", "Europe"),(
	"OM", "Oman", "Asia"),(
	"PK", "Pakistan", "Asia"),(
	"PW", "Palau", "Oceania"),(
	"PS", "Palestinia", "Asia"),(
	"PA", "Panama", "North America"),(
	"PG", "Papua New Guinea", "Oceania"),(
	"PY", "Paraguay", "South America"),(
	"PE", "Peru", "South America"),(
	"PH", "Philippines", "Asia"),(
	"PN", "Pitcairn", "Oceania"),(
	"PL", "Poland", "Europe"),(
	"PT", "Portugal", "Europe"),(
	"PR", "Puerto Rico", "North America"),(
	"QA", "Qatar", "Asia"),(
	"RE", "Reunion", "Africa"),(
	"RO", "Romania", "Europe"),(
	"RU", "Russian Federation", "Europe"),(
	"RW", "Rwanda", "Africa"),(
	"SH", "Saint Helena", "Africa"),(
	"KN", "Saint Kitts and Nevis", "North America"),(
	"LC", "Saint Lucia", "North America"),(
	"PM", "Saint Pierre and Miquelon", "North America"),(
	"VC", "Saint Vincent and The Grenadines", "North America"),(
	"WS", "Samoa", "Oceania"),(
	"SM", "San Marino", "Europe"),(
	"ST", "Sao Tome and Principe", "Africa"),(
	"SA", "Saudi Arabia", "Asia"),(
	"SN", "Senegal", "Africa"),(
	"RS", "Serbia", "Europe"),(
	"SC", "Seychelles", "Africa"),(
	"SL", "Sierra Leone", "Africa"),(
	"SG", "Singapore", "Asia"),(
	"SK", "Slovakia", "Europe"),(
	"SI", "Slovenia", "Europe"),(
	"SB", "Solomon Islands", "Oceania"),(
	"SO", "Somalia", "Africa"),(
	"ZA", "South Africa", "Africa"),(
	"GS", "South Georgia and The South Sandwich Islands", "Antarctica"),(
	"ES", "Spain", "Europe"),(
	"LK", "Sri Lanka", "Asia"),(
	"SD", "Sudan", "Africa"),(
	"SR", "Suriname", "South America"),(
	"SJ", "Svalbard and Jan Mayen", "Europe"),(
	"SZ", "Swaziland", "Africa"),(
	"SE", "Sweden", "Europe"),(
	"CH", "Switzerland", "Europe"),(
	"SY", "Syrian Arab Republic", "Asia"),(
	"TW", "Taiwan, Province of China", "Asia"),(
	"TJ", "Tajikistan", "Asia"),(
	"TZ", "Tanzania, United Republic of", "Africa"),(
	"TH", "Thailand", "Asia"),(
	"TL", "Timor-leste", "Asia"),(
	"TG", "Togo", "Africa"),(
	"TK", "Tokelau", "Oceania"),(
	"TO", "Tonga", "Oceania"),(
	"TT", "Trinidad and Tobago", "North America"),(
	"TN", "Tunisia", "Africa"),(
	"TR", "Turkey", "Asia"),(
	"TM", "Turkmenistan", "Asia"),(
	"TC", "Turks and Caicos Islands", "North America"),(
	"TV", "Tuvalu", "Oceania"),(
	"UG", "Uganda", "Africa"),(
	"UA", "Ukraine", "Europe"),(
	"AE", "United Arab Emirates", "Asia"),(
	"GB", "United Kingdom", "Europe"),(
	"US", "United States", "North America"),(
	"UM", "United States Minor Outlying Islands", "Oceania"),(
	"UY", "Uruguay", "South America"),(
	"UZ", "Uzbekistan", "Asia"),(
	"VU", "Vanuatu", "Oceania"),(
	"VE", "Venezuela", "South America"),(
	"VN", "Viet Nam", "Asia"),(
	"VG", "Virgin Islands, British", "North America"),(
	"VI", "Virgin Islands, U.S.", "North America"),(
	"WF", "Wallis and Futuna", "Oceania"),(
	"EH", "Western Sahara", "Africa"),(
	"YE", "Yemen", "Asia"),(
	"ZM", "Zambia", "Africa"),(
	"ZW", "Zimbabwe", "Africa");
 
');

$installer->endSetup();