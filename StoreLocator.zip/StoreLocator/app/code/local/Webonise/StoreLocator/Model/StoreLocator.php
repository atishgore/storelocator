<?php

class Webonise_StoreLocator_Model_StoreLocator 
	extends Mage_Core_Model_Abstract
{
    protected $_resource;

    protected function _construct()
    {
        $this->_init('webonise_storeLocator/storeLocator');
    }

    protected function _getConnection()
    {
    	$resource = Mage::getSingleton('core/resource');
		$readConnection = $resource->getConnection('core_read');
		$this->_resource = $resource;
		return $readConnection;
    }

    public function getContinentCountry($value = null)
    {
    	$readConnection = $this->_getConnection();
    	$query = 'SELECT code, country FROM ' . $this->_resource->getTableName('webonise_continents_country') . " where continent =  '$value'";
		$results = $readConnection->fetchAll($query);
		return $results;
    }

    public function getCountryStore($value = null)
    {
        $readConnection = $this->_getConnection();
        $query = 'SELECT * FROM ' . $this->_resource->getTableName('webonise_store_locator') . " where country =  '$value'";      
        $results = $readConnection->fetchAll($query);
        return $results;
    }

    public function getStoreInfo($value = null)
    {
        $readConnection = $this->_getConnection();
        $query = 'SELECT pincode, city FROM ' . $this->_resource->getTableName('webonise_store_locator') . " where country =  '$value'";      
        $results = $readConnection->fetchAll($query);
        return $results;
    }
}