<?php

class Webonise_StoreLocator_Block_Store
    extends Mage_Core_Block_Template
{
    public function getContinents()
    {
    	/**
		 * Get the resource model
		 */
		$resource = Mage::getSingleton('core/resource');

		/**
		 * Retrieve the read connection
		 */
		$readConnection = $resource->getConnection('core_read');

		$query = 'SELECT DISTINCT continent FROM ' . $resource->getTableName('webonise_continents_country');
		//take a look at your config.xml that added extensa_econt_city table for the correct name   
		/**
		 * Execute the query and store the results in $results
		 */
		$results = $readConnection->fetchAll($query);

		return $results;
    }
}