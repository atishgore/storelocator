<?php

class Webonise_StoreLocator_Block_Adminhtml_Store_Edit_Form
    extends Mage_Adminhtml_Block_Widget_Form
{
    /**
     * Init class
     */
    public function __construct()
    {
        parent::__construct();

        $this->setId('webonise_storeLocator_form');
        $this->setTitle($this->__('Store Information'));
    }

    /**
     * Setup form fields for inserts/updates
     *
     * return Mage_Adminhtml_Block_Widget_Form
     */
    protected function _prepareForm()
    {
        $model = Mage::registry('webonise_storeLocator');

        // $form = new Varien_Data_Form();

        $form = new Varien_Data_Form(array(
                'id' => 'edit_form',
                'action' => $this->getUrl('*/*/save', array('id' => $this->getRequest()->getParam('id'))),
                'method' => 'post',
                'enctype' => 'multipart/form-data',
        ));
 
        $form->setUseContainer(true);
 
        $this->setForm($form);

       $fieldset = $form->addFieldset('base_fieldset', array(
            'legend'    => $this->__('Store Information'),
            'class'     => 'fieldset-wide',
        ));

        if ($model->getId()) {
            $fieldset->addField('id', 'hidden', array(
                'name' => 'id',
            ));
        }

        $fieldset->addField('name', 'text', array(
            'name'      => 'name',
            'label'     => $this->__('Name'),
            'title'     => $this->__('Name'),
            'style'     => 'width:26% !important',
            'required'  => true,
        ));

        $fieldset->addField('continent', 'text', array(
            'name'      => 'continent',
            'label'     => $this->__('Continent'),
            'title'     => $this->__('Continent'),
            'style'     => 'width:26% !important',
            'required'  => true,
        ));

        $fieldset->addField('country', 'select', array(
            'name'      => 'country',
            'label'     => $this->__('Country'),
            'title'     => $this->__('Country'),
            'values'    => Mage::getModel('adminhtml/system_config_source_country')->toOptionArray(), 
            'required'  => true,
        ));

        $fieldset->addField('latitude', 'text', array(
            'name'      => 'latitude',
            'label'     => $this->__('Latitude'),
            'title'     => $this->__('Latitude'),
            'style'     => 'width:26% !important',
            'required'  => true,
        ));

        $fieldset->addField('longitude', 'text', array(
            'name'      => 'longitude',
            'label'     => $this->__('Longitude'),
            'title'     => $this->__('Longitude'),
            'style'     => 'width:26% !important',
            'required'  => true,
        ));

        $fieldset->addField('pincode', 'text', array(
            'name'      => 'pincode',
            'label'     => $this->__('Pincode'),
            'title'     => $this->__('Pincode'),
            'style'     => 'width:26% !important',
            'required'  => true,
        ));

        $fieldset->addField('state', 'text', array(
            'name'      => 'state',
            'label'     => $this->__('State'),
            'title'     => $this->__('State'),
            'style'     => 'width:26% !important',
            'required'  => false,
        ));

        $fieldset->addField('city', 'text', array(
            'name'      => 'city',
            'label'     => $this->__('City'),
            'title'     => $this->__('City'),
            'style'     => 'width:26% !important',
            'required'  => false,
        ));

        $form->setValues($model->getData());
        $form->setUseContainer(true);
        $this->setForm($form);

        return parent::_prepareForm();
    }
}