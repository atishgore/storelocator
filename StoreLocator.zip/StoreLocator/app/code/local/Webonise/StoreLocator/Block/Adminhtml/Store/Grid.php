<?php

class Webonise_StoreLocator_Block_Adminhtml_Store_Grid
    extends Mage_Adminhtml_Block_Widget_Grid
{
    public function __construct()
    {
        parent::__construct();
        $this->setDefaultSort('id');
        $this->setId('webonise_storeLocator_grid');
        $this->setDefaultDir('asc');
        $this->setSaveParametersInSession(true);
    }

    protected function _getCollectionClass()
    {
        // This is the model we are using for the grid
        return 'webonise_storeLocator/storeLocator_collection';
    }

    protected function _prepareCollection()
    {
        // Get and set our collection for the grid
        $collection = Mage::getResourceModel($this->_getCollectionClass());
        $this->setCollection($collection);

        return parent::_prepareCollection();
    }

    protected function _prepareColumns()
    {
        // Add the columns that should appear in the grid
        $this->addColumn('id',
            array(
                'header'=> $this->__('ID'),
                'align' =>'right',
                'width' => '50px',
                'index' => 'id'
            )
        );

        $this->addColumn('name',
            array(
                'header'=> $this->__('Store Name'),
                'index' => 'name'
            )
        );

        $this->addColumn('continent',
            array(
                'header'=> $this->__('Continent'),
                'index' => 'continent'
            )
        );

        $this->addColumn('country',
            array(
                'header'=> $this->__('Country'),
                'index' => 'country',
                'type'      =>'country',
            )
        );

        $this->addColumn('latitude',
            array(
                'header'=> $this->__('Latitude'),
                'index' => 'latitude'
            )
        );

        $this->addColumn('longitude',
            array(
                'header'=> $this->__('Longitude'),
                'index' => 'longitude'
            )
        );

        $this->addColumn('pincode',
            array(
                'header'=> $this->__('Pincode'),
                'index' => 'pincode'
            )
        );

        $this->addColumn('state',
            array(
                'header'=> $this->__('State'),
                'index' => 'state'
            )
        );

        $this->addColumn('city',
            array(
                'header'    => $this->__('City'),
                'index'     => 'city'
            )
        );

        return parent::_prepareColumns();
    }

    public function getRowUrl($row)
    {
        // This is where our row data will link to
        return $this->getUrl('*/*/edit', array('id' => $row->getId()));
    }
}