<?php

class Webonise_StoreLocator_IndexController
    extends Mage_Core_Controller_Front_Action
{
    public function indexAction()
    {
        $this->loadLayout();
        $this->renderLayout();
    }

    public function saveAction()
    {
        $result = $this->getRequest()->getParam('telephone');
        $this->getResponse()->setBody(Mage::helper('core')->jsonEncode($result));
    }

    public function countryAction() {
        $continent = $this->getRequest()->getParam('continent');
        $html = "";
        $storeLocatorModel = Mage::getModel('webonise_storeLocator/storeLocator')->load($continent);
        $results = $storeLocatorModel->getContinentCountry($continent);
        if(count($results) > 0){
            $html .= "<select class='select required-entry' name='country' id='country' onchange='getStore(this.value);'>
            <option value=''>--Please Select--</option>";
            foreach ($results as $value) {
            	$html .= "<option value='" . $value['code'] . "'>" . $value['country'] . "</option>";
            }
            $html .= "</select>";
        } else {
            $html .= "<input name='country' id='country' title='".Mage::helper('webonise_storeLocator')->__('State')."' value='' class='input-text' type='text' />";
        }
        echo $html;
    }

    public function storeInfoAction()
    {
        $country = $this->getRequest()->getParam('country');
        $storeLocatorModel = Mage::getModel('webonise_storeLocator/storeLocator')->load($country);
        $results = $storeLocatorModel->getStoreInfo($country);
        echo json_encode($results);
        exit;
    }

    public function storeAction() 
    {
        $country = $this->getRequest()->getParam('country');
        $html = "";
        $storeLocatorModel = Mage::getModel('webonise_storeLocator/storeLocator')->load($country);
        $results = $storeLocatorModel->getCountryStore($country);

		if(count($results) > 0){
            // $html .= "<table border='1'><tr><th width='20%'>Id</th><th width='20%'>Name</th><th width='30%'>Continent</th><th width='20%'>Country</th><th width='20%'>City</th></tr><tr>";
            $html .= '<div class="page-title">
                <h2>'. $this->__('Store Information') .'</h2>
                </div>
                <table id="store-table" class="data-table">
                <colgroup>
                <col width="1">
                <col>
                <col width="1">
                <col width="1">
                <col>
                </colgroup>
                <thead>
                <tr class="first last">
                <th>Id</th>
                <th>Name</th>
                <th>Continent</th>
                <th>Country</th>
                <th>Latitude</th>
                <th>Longitude</th>
                <th>Pincode</th>
                <th>State</th>
                <th>City</th>
                </tr>
                </thead>
                <tbody>';
                foreach ($results as $value) {
                    $html .= "<tr>
                            <td>".$value['id']."</td>
                            <td>".$value['name']."</td>
                            <td>".$value['continent']."</td>
                            <td>".$value['country']."</td>
                            <td>".$value['latitude']."</td>
                            <td>".$value['longitude']."</td>
                            <td>".$value['pincode']."</td>
                            <td>".$value['state']."</td>
                            <td>".$value['city']."</td>
                            </tr>";
                }
                $html .= '</tbody>
                    </table>';
        } else {
            $html .= "Stores not exists!";
        }
        echo $html;
    }
}